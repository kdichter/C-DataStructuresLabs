// Author: Professor William Killian
// Date: 2019 May 17
// Class: CSCI 362.93 - Data Structures
// Assignment: 2a - Analyzing Sorting Algorithms
//
// Description:
//
// Header file for templated sorting algorithms, specifically
// bubble sort (optimized), insertion sort, and selection sort.
// Includes a 'Statistics' datatype for aggregating counts for
// swaps and comparisons.

#ifndef SORTING_ALGORITHMS_HPP_
#define SORTING_ALGORITHMS_HPP_

#include <vector>

struct Statistics {
  // default constructs swaps and compares to zero
  std::size_t numSwaps { 0 };
  std::size_t numCompares { 0 };
};

template <typename T>
void
bubbleSort (std::vector<T>& v, Statistics& s)
{

}

template <typename T>
void
insertionSort (std::vector<T>& v, Statistics& s)
{

}

template <typename T>
void
selectionSort (std::vector<T>& v, Statistics& s)
{

}

#endif
